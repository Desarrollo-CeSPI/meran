#define SPH_SVN_TAG "rel20"
#define SPH_SVN_REV 3135
#define SPH_SVN_REVSTR "3135"
#define SPH_SVN_TAGREV "r3135"
#define SPHINX_TAG "-release"
